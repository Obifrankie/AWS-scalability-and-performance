def hello(event, context):
    print("My First Lambda Function")